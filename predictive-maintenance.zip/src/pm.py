"""
Predictive Maintenance on NASA C-MAPSS turbofan sensor data (FD001)

1. Explore sensor data and find the sensors that show wear
2. Anomaly detection: early warning when a machine leaves its own normal range
3. Time-series forecasting (ARIMA): forecast the health signal and predict when it crosses the failure limit
4. Classification: will the engine fail within the next 30 cycles? (yes / no)
5. Remaining useful life (RUL) regression
6. Business view: reactive vs. scheduled vs. predictive maintenance

Run from the repository root:  python src/pm.py
"""
import json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import (roc_auc_score, precision_score, recall_score,
                             confusion_matrix, mean_squared_error, mean_absolute_error)

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parents[1]
DATA, IMG = ROOT / "data", ROOT / "images"
IMG.mkdir(exist_ok=True)
SEED = 42
HORIZON = 30          # "fails within 30 cycles" = maintenance warning window
plt.rcParams.update({"figure.dpi": 110, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.alpha": .25, "font.size": 10})
BLUE, RED, GREY = "#2563eb", "#dc2626", "#6b7280"

# ---------------------------------------------------------------- 0. load
cols = ["unit", "cycle", "op1", "op2", "op3"] + [f"s{i}" for i in range(1, 22)]
read = lambda f: pd.read_csv(DATA / f, sep=r"\s+", header=None, names=cols)
train, test = read("train_FD001.txt"), read("test_FD001.txt")
true_rul = pd.read_csv(DATA / "RUL_FD001.txt", header=None, names=["RUL"])
true_rul["unit"] = np.arange(1, len(true_rul) + 1)

train["RUL"] = train.groupby("unit")["cycle"].transform("max") - train["cycle"]
last = test.groupby("unit")["cycle"].max().rename("last").reset_index().merge(true_rul)
test = test.merge(last, on="unit")
test["RUL"] = test["RUL"] + test["last"] - test["cycle"]
test = test.drop(columns="last")

# ---------------------------------------------------------------- 1. explore
sensors = [c for c in cols[5:] if train[c].std() > 1e-3]
corr = train[sensors + ["RUL"]].corr()["RUL"].drop("RUL")
key = corr[corr.abs() > 0.5].index.tolist()          # sensors that clearly move with wear
names = {"s2": "LPC outlet temp", "s3": "HPC outlet temp", "s4": "LPT outlet temp",
         "s7": "HPC outlet pressure", "s11": "HPC static pressure", "s12": "Fuel flow ratio",
         "s15": "Bypass ratio", "s17": "Bleed enthalpy", "s20": "HPT coolant bleed",
         "s21": "LPT coolant bleed"}

fig, ax = plt.subplots(2, 2, figsize=(10, 6))
for a, s in zip(ax.flat, ["s4", "s11", "s7", "s12"]):
    for u in range(1, 11):
        d = train[train.unit == u]
        a.plot(-d.RUL, d[s], lw=.7, alpha=.7)
    a.set_title(f"{s} – {names[s]}"); a.set_xlabel("cycles before failure")
fig.suptitle("Sensor readings drift as the engine wears out (10 engines)", weight="bold")
fig.tight_layout(); fig.savefig(IMG / "1_sensor_trends.png"); plt.close()

# Health index: one number per cycle that summarises all wear sensors (1 = healthy, 0 = failed).
# Early life counts as fully healthy (remaining life capped at 125 cycles, the standard for this data).
CAP = 125
scaler = StandardScaler().fit(train[key])
hi_target = train["RUL"].clip(upper=CAP) / CAP
hi_model = LinearRegression().fit(scaler.transform(train[key]), hi_target)
for df in (train, test):
    df["HI"] = hi_model.predict(scaler.transform(df[key]))
    df["HI_smooth"] = df.groupby("unit")["HI"].transform(lambda x: x.rolling(10, min_periods=1).mean())
FAIL_LIMIT = train[train.RUL == 0]["HI_smooth"].median()

# ---------------------------------------------------------------- 2. anomaly detection
# Unsupervised early warning: each engine is compared with its OWN first 30 cycles ("normal").
# Alarm when the smoothed health index falls more than 3 standard deviations below normal.
# Evaluated on the 100 unseen NASA test engines, where the true failure cycle is known.
def first_alarm(d):
    base = d.iloc[:30]["HI"]
    thr = base.mean() - 3 * base.std()
    hit = d[(d.HI_smooth < thr) & (d.cycle > 30)]
    return (hit.cycle.iloc[0] if len(hit) else None), thr

rows = []
for u, d in test.groupby("unit"):
    if len(d) <= 30:
        continue
    fail_cycle = d.cycle.max() + d.RUL.iloc[-1]
    a_cycle, _ = first_alarm(d)
    rows.append({"unit": u, "rul_end": d.RUL.iloc[-1], "alarm": a_cycle,
                 "lead": (fail_cycle - a_cycle) if a_cycle else None})
an = pd.DataFrame(rows)
close = an[an.rul_end <= HORIZON]                    # engines that were about to fail when data ended
healthy = an[an.rul_end > 100]                       # engines that were still far from failure
anomaly = {"test_engines_close_to_failure": len(close),
           "warned_before_failure": int(close.alarm.notna().sum()),
           "median_warning_cycles_before_failure": float(close.lead.median()),
           "test_engines_far_from_failure": len(healthy),
           "false_alarms_on_healthy_engines": int(healthy.alarm.notna().sum())}

u = int(close.sort_values("lead").iloc[len(close) // 2].unit)
d = test[test.unit == u]
a_cycle, thr = first_alarm(d)
fail_cycle = d.cycle.max() + d.RUL.iloc[-1]
plt.figure(figsize=(9, 3.6))
plt.plot(d.cycle, d.HI, color=GREY, lw=.6, label="health index (raw)")
plt.plot(d.cycle, d.HI_smooth, color=BLUE, lw=2, label="health index (10-cycle average)")
plt.axhline(thr, color=RED, ls="--", label="anomaly limit (own normal − 3σ)")
plt.axvline(a_cycle, color=RED, alpha=.5)
plt.text(a_cycle + 2, d.HI.max(), f"alarm at cycle {a_cycle}\n{fail_cycle - a_cycle} cycles before failure", color=RED, va="top")
plt.title(f"Anomaly detection – unseen test engine {u}", weight="bold"); plt.xlabel("cycle")
plt.legend(loc="lower left", fontsize=8); plt.tight_layout(); plt.savefig(IMG / "2_anomaly_detection.png"); plt.close()

# ---------------------------------------------------------------- 3. ARIMA forecast of failure time
# For each test engine: fit ARIMA(1,1,0) with drift on the last 30 cycles of its health index,
# forecast forward and read off when the forecast crosses the failure limit.
def arima_failure(series, win=30, max_steps=300):
    y = series.rolling(5, min_periods=1).mean().values[-win:]
    fc = ARIMA(y, order=(1, 1, 0), trend="t").fit().get_forecast(max_steps)
    mean = fc.predicted_mean
    hit = np.where(mean <= FAIL_LIMIT)[0]
    return (hit[0] + 1 if len(hit) else max_steps), mean, fc.conf_int(alpha=.2)

rows = []
for u, d in test.groupby("unit"):
    pred, _, _ = arima_failure(d["HI"])
    rows.append({"unit": u, "true": d.RUL.iloc[-1], "arima": pred})
ar = pd.DataFrame(rows)
ar_cap_err = np.abs(ar.true.clip(upper=CAP) - ar.arima.clip(upper=CAP))
arima_res = {"engines": len(ar), "mae_capped": round(float(ar_cap_err.mean()), 1)}

# show a TYPICAL engine: forecast error closest to the median error
cand = ar[(ar.true > 25) & (ar.true < 80)].assign(e=lambda x: (x.true - x.arima).abs())
u = int(cand.iloc[(cand.e - ar_cap_err.median()).abs().argsort().iloc[0]].unit)
d = test[test.unit == u]
pred, mean, ci = arima_failure(d["HI"])
steps = np.arange(1, len(mean) + 1) + d.cycle.max()
k = min(len(mean), pred + 25)
plt.figure(figsize=(9, 3.8))
plt.plot(d.cycle, d.HI, color=GREY, lw=.6, label="health index (observed)")
plt.plot(steps[:k], mean[:k], color=BLUE, lw=2, label="ARIMA(1,1,0) forecast")
plt.fill_between(steps[:k], ci[:k, 0], ci[:k, 1], color=BLUE, alpha=.12, label="80% interval")
plt.axhline(FAIL_LIMIT, color=RED, ls="--", label="failure limit")
plt.axvline(d.cycle.max() + d.RUL.iloc[-1], color="k", alpha=.6)
plt.text(d.cycle.max() + 2, d.HI.max(), f"forecast: fails in {pred} cycles\nactual: {d.RUL.iloc[-1]} cycles", va="top")
plt.title(f"Time-series forecast of the health index – test engine {u}", weight="bold"); plt.xlabel("cycle")
plt.legend(loc="lower left", fontsize=8); plt.tight_layout(); plt.savefig(IMG / "3_arima_forecast.png"); plt.close()

# ---------------------------------------------------------------- 4. classification
def features(df):
    g = df.groupby("unit")
    out = df[["unit", "cycle", "RUL"] + key].copy()
    for s in key:
        out[f"{s}_mean10"] = g[s].transform(lambda x: x.rolling(10, min_periods=1).mean())
        out[f"{s}_std10"] = g[s].transform(lambda x: x.rolling(10, min_periods=2).std()).fillna(0)
        out[f"{s}_slope20"] = g[s].transform(lambda x: x.diff(19).fillna(0) / 19)
    return out

ftr, fte = features(train), features(test)
X_cols = [c for c in ftr.columns if c not in ("unit", "cycle", "RUL")]
ftr["fail30"] = (ftr.RUL <= HORIZON).astype(int)
fte["fail30"] = (fte.RUL <= HORIZON).astype(int)
test_last = fte.groupby("unit").tail(1)          # NASA test set: one prediction per engine, at its last cycle

models = {"Logistic regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, C=.5)),
          "Random forest": RandomForestClassifier(n_estimators=300, min_samples_leaf=5, random_state=SEED, n_jobs=-1)}
clf_res = {}
for n, m in models.items():
    m.fit(ftr[X_cols], ftr.fail30)
    p_all = m.predict_proba(fte[X_cols])[:, 1]
    p_last = m.predict_proba(test_last[X_cols])[:, 1]
    yhat = (p_last >= .5).astype(int)
    clf_res[n] = {"auc_all_test_cycles": round(roc_auc_score(fte.fail30, p_all), 3),
                  "auc_test_engines": round(roc_auc_score(test_last.fail30, p_last), 3),
                  "precision": round(precision_score(test_last.fail30, yhat), 3),
                  "recall": round(recall_score(test_last.fail30, yhat), 3),
                  "confusion_matrix [[tn, fp], [fn, tp]]": confusion_matrix(test_last.fail30, yhat).tolist(),
                  # in maintenance a missed failure costs more than a false alarm -> lower threshold
                  "precision_at_0.3": round(precision_score(test_last.fail30, p_last >= .3), 3),
                  "recall_at_0.3": round(recall_score(test_last.fail30, p_last >= .3), 3)}

rf = models["Random forest"]
imp = pd.Series(rf.feature_importances_, X_cols).sort_values().tail(10)
plt.figure(figsize=(8, 4))
plt.barh([i.replace("_", " ") for i in imp.index], imp.values, color=BLUE)
plt.title("Top 10 warning signals (random forest)", weight="bold"); plt.xlabel("importance")
plt.tight_layout(); plt.savefig(IMG / "4_feature_importance.png"); plt.close()

cm = np.array(clf_res["Logistic regression"]["confusion_matrix [[tn, fp], [fn, tp]]"])
fig, a = plt.subplots(figsize=(4.2, 3.6))
a.imshow(cm, cmap="Blues"); a.grid(False)
for i in range(2):
    for j in range(2):
        a.text(j, i, cm[i, j], ha="center", va="center", fontsize=14, color="white" if cm[i, j] > cm.max() / 2 else "k")
a.set_xticks([0, 1], ["predicted OK", "predicted fail"]); a.set_yticks([0, 1], ["actual OK", "actual fail"])
a.set_title(f"Fails within {HORIZON} cycles?\nLogistic regression, 100 test engines", weight="bold")
fig.tight_layout(); fig.savefig(IMG / "5_confusion_matrix.png"); plt.close()

# ---------------------------------------------------------------- 5. remaining useful life
reg = RandomForestRegressor(n_estimators=300, min_samples_leaf=5, random_state=SEED, n_jobs=-1)
reg.fit(ftr[X_cols], ftr.RUL.clip(upper=CAP))
rul_pred = reg.predict(test_last[X_cols])
rul_true = test_last.RUL.clip(upper=CAP)
rul_res = {"rmse": round(float(np.sqrt(mean_squared_error(rul_true, rul_pred))), 1),
           "mae": round(float(mean_absolute_error(rul_true, rul_pred)), 1),
           "arima_baseline_mae": arima_res["mae_capped"],
           "improvement_vs_arima": round(1 - float(mean_absolute_error(rul_true, rul_pred)) / arima_res["mae_capped"], 3)}

plt.figure(figsize=(5, 4.4))
plt.scatter(rul_true, rul_pred, color=BLUE, alpha=.7)
plt.plot([0, CAP], [0, CAP], color=GREY, ls="--")
plt.xlabel("actual remaining life (cycles)"); plt.ylabel("predicted remaining life (cycles)")
plt.title(f"Remaining useful life – RMSE {rul_res['rmse']} cycles", weight="bold")
plt.tight_layout(); plt.savefig(IMG / "6_rul_prediction.png"); plt.close()

# ---------------------------------------------------------------- 6. business view (illustrative costs)
# Simulate three maintenance policies on the 100 training engines (full life known).
# Predictive policy uses OUT-OF-FOLD remaining-life predictions (model never saw that engine).
# Cost assumptions (illustrative, not from NASA): unplanned failure = 10, planned service = 2.
from sklearn.model_selection import GroupKFold
UNPLANNED, PLANNED, SCHED, TRIGGER = 10, 2, 125, 20
oof = np.zeros(len(ftr))
for tr, va in GroupKFold(5).split(ftr, groups=ftr.unit):
    m = RandomForestRegressor(n_estimators=200, min_samples_leaf=5, random_state=SEED, n_jobs=-1)
    m.fit(ftr.iloc[tr][X_cols], ftr.iloc[tr].RUL.clip(upper=CAP))
    oof[va] = m.predict(ftr.iloc[va][X_cols])
ftr["rul_oof"] = oof

def policy(kind):
    cost = cycles = fails = 0
    for u, d in ftr.groupby("unit"):
        life = d.cycle.max()
        if kind == "reactive":
            stop, failed = life, True
        elif kind == "scheduled":
            stop, failed = min(SCHED, life), life <= SCHED
        else:
            t = d[d.rul_oof <= TRIGGER]
            stop, failed = (t.cycle.iloc[0], False) if len(t) else (life, True)
        cost += UNPLANNED if failed else PLANNED
        cycles += stop; fails += failed
    return {"cost_per_1000_cycles": round(1000 * cost / cycles, 2), "unplanned_failures": int(fails),
            "life_used": round(cycles / ftr.groupby("unit").cycle.max().sum(), 3)}

business = {p: policy(p) for p in ("reactive", "scheduled", "predictive")}
business["assumptions"] = {"unplanned_failure_cost": UNPLANNED, "planned_service_cost": PLANNED,
                           "scheduled_interval_cycles": SCHED, "predictive_trigger_rul": TRIGGER}
business["predictive_saving_vs_reactive"] = round(1 - business["predictive"]["cost_per_1000_cycles"] / business["reactive"]["cost_per_1000_cycles"], 3)
business["predictive_saving_vs_scheduled"] = round(1 - business["predictive"]["cost_per_1000_cycles"] / business["scheduled"]["cost_per_1000_cycles"], 3)

labels = ["Reactive\n(run to failure)", f"Scheduled\n(every {SCHED} cycles)", "Predictive\n(this model)"]
vals = [business[p]["cost_per_1000_cycles"] for p in ("reactive", "scheduled", "predictive")]
fig, ax = plt.subplots(1, 2, figsize=(10, 3.8))
b1 = ax[0].bar(labels, vals, color=[GREY, GREY, BLUE]); ax[0].bar_label(b1, fmt="%.1f")
ax[0].set_title("Maintenance cost per 1,000 cycles", weight="bold")
lu = [100 * business[p]["life_used"] for p in ("reactive", "scheduled", "predictive")]
fl = [business[p]["unplanned_failures"] for p in ("reactive", "scheduled", "predictive")]
b2 = ax[1].bar(labels, lu, color=[GREY, GREY, BLUE])
ax[1].bar_label(b2, labels=[f"{v:.0f}% life used\n{f} failures" for v, f in zip(lu, fl)], fontsize=8)
ax[1].set_ylim(0, 125); ax[1].set_title("Engine life used & unplanned failures", weight="bold")
fig.suptitle("100 engines, illustrative costs: failure = 10, planned service = 2", fontsize=9, color=GREY)
fig.tight_layout(); fig.savefig(IMG / "7_business_case.png"); plt.close()

results = {"data": {"train_engines": int(train.unit.nunique()), "train_rows": len(train),
                    "test_engines": int(test.unit.nunique()), "wear_sensors": key},
           "anomaly_detection": anomaly, "arima_failure_forecast": arima_res,
           "classification_fail_within_30": clf_res, "remaining_useful_life": rul_res,
           "business_case": business}
(ROOT / "results.json").write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
