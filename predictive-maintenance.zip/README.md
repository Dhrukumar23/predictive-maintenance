# Predictive Maintenance – Turbofan Engine Sensor Data

**Question:** can we see from sensor data that a machine is wearing out, and plan the service *before* it breaks?

I used NASA's C-MAPSS dataset (FD001): 100 jet engines, each run from new until failure, with 21 sensors recorded every operating cycle (temperatures, pressures, fan speeds, fuel flow). I tested the models on 100 separate engines that they never saw during training.

| What | Result |
|---|---|
| Anomaly detection (early warning) | **25 of 25** engines close to failure were flagged, a median **62 cycles** before failure; **0 false alarms** on 33 healthy engines |
| Classification: "fails within 30 cycles?" | **AUC 0.985**, precision 95% (logistic regression) |
| Remaining useful life | Error of **13.4 cycles** (RMSE 18.3), **42% better** than the ARIMA time-series baseline |
| Business case (illustrative costs) | **78% lower** maintenance cost than run-to-failure, **33% lower** than a fixed service schedule, with 0 unplanned failures |

---

## 1. Which sensors show wear?

12 of the 21 sensors correlate strongly with remaining life (|r| > 0.5). Temperatures and pressures rise as the engine wears; some ratios fall. I combined these 12 sensors into one **health index** per cycle (1 = healthy, 0 = failed) with a linear model.

![Sensor trends](images/1_sensor_trends.png)

## 2. Anomaly detection – early warning without labels

Each engine is compared with **its own first 30 cycles** ("normal state"). An alarm goes off when the smoothed health index drops more than 3 standard deviations below that normal level. This works without any failure history, so it is the method you can use on day one for a new machine type.

On the unseen test engines:
- all 25 engines that were within 30 cycles of failure had already raised an alarm, a median of 62 cycles before failure;
- none of the 33 engines that were still far from failure (more than 100 cycles left) raised an alarm.

![Anomaly detection](images/2_anomaly_detection.png)

## 3. Time-series forecasting (ARIMA)

For each test engine I fit an **ARIMA(1,1,0) model with drift** on the last 30 cycles of its health index, forecast forward, and read off when the forecast crosses the failure limit.

- Mean absolute error: **23.1 cycles** (remaining life capped at 125, the standard for this dataset).
- Strength: simple, explainable, works one engine at a time with no training data.
- Weakness: it assumes a straight-line trend, but wear **accelerates** near the end, so ARIMA tends to predict failure too late (see example below). That's the motivation for the machine learning models.

![ARIMA forecast](images/3_arima_forecast.png)

## 4. Classification – will it fail within the next 30 cycles?

Features per cycle: current sensor values, 10-cycle rolling mean and standard deviation, and 20-cycle slope for each wear sensor. Label: 1 if the engine fails within 30 cycles. Evaluated on the last cycle of each of the 100 NASA test engines.

| Model | AUC | Precision | Recall | Recall at threshold 0.3 |
|---|---|---|---|---|
| Logistic regression | 0.985 | 0.95 | 0.72 | 0.76 (precision 0.91) |
| Random forest | 0.986 | 0.94 | 0.64 | 0.80 (precision 0.91) |

In maintenance a **missed failure costs more than a false alarm**, so the threshold should be set lower than 0.5. At 0.3, recall improves while precision stays above 90%.

![Confusion matrix](images/5_confusion_matrix.png) ![Feature importance](images/4_feature_importance.png)

The strongest warning signals are the 10-cycle averages of LPC outlet temperature (s2), HPC static pressure (s11) and LPT outlet temperature (s4). In other words, the **trend** of a sensor is more useful than a single reading.

## 5. Remaining useful life (RUL)

A random forest regression predicts how many cycles each test engine has left: **MAE 13.4 cycles, RMSE 18.3 cycles**, a 42% lower error than the ARIMA baseline (23.1).

![RUL prediction](images/6_rul_prediction.png)

## 6. Business case – what is it worth?

I simulated three maintenance policies on the 100 training engines. The predictive policy uses **out-of-fold** predictions (5-fold, grouped by engine), so the model never saw the engine it decides on. The service is planned when the predicted remaining life drops to 20 cycles.

*Illustrative cost assumptions: unplanned failure = 10, planned service = 2.*

| Policy | Cost per 1,000 cycles | Unplanned failures | Engine life used |
|---|---|---|---|
| Reactive (run to failure) | 48.5 | 100 | 100% |
| Scheduled (every 125 cycles) | 16.0 | 0 | 61% |
| **Predictive (this model)** | **10.7** | **0** | **91%** |

A fixed schedule avoids failures but throws away about 40% of each engine's useful life. Predictive maintenance avoids failures **and** uses 91% of the life.

![Business case](images/7_business_case.png)

---

## How to run

```bash
pip install -r requirements.txt
python src/pm.py          # writes results.json and all charts to images/
```

## Data

NASA C-MAPSS Turbofan Engine Degradation Simulation, subset FD001 (one operating condition, one failure mode), from the NASA Prognostics Center of Excellence Data Repository. The data is simulated by NASA's engine model, not taken from real flights.

## Limitations and next steps

- FD001 has one operating condition and one failure mode. Real machines (for example welding or manufacturing equipment) run in many conditions, so the health index would need normalisation per operating mode (subsets FD002–FD004).
- Cost figures are illustrative. With real service and downtime costs, the trigger point (20 cycles) can be optimised.
- Next: test the approach on FD002–FD004 and try sequence models (LSTM) as a comparison.

**Tools:** Python, pandas, statsmodels (ARIMA), scikit-learn (logistic regression, random forest), matplotlib
